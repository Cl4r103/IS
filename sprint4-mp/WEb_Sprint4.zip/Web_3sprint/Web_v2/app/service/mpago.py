# app/service/mpago.py
"""Mercado Pago SDK wrapper utilities."""

from __future__ import annotations

import logging
import os
from typing import Any, Dict

# SDK oficial
try:  # pragma: no cover - dependencia opcional en tests
    import mercadopago  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    mercadopago = None  # type: ignore

# Logger seguro: usa current_app.logger si existe; si no, logging estándar
try:  # pragma: no cover
    from flask import current_app  # type: ignore
except Exception:  # pragma: no cover
    current_app = None  # type: ignore


def _get_logger() -> logging.Logger:
    if current_app is not None:
        try:
            # Puede lanzar RuntimeError si no hay app context
            return current_app.logger  # type: ignore[return-value]
        except Exception:
            pass
    return logging.getLogger(__name__)


class MPagoClient:
    """Pequeño helper alrededor del SDK de Mercado Pago."""

    def __init__(self, access_token: str | None = None) -> None:
        lg = _get_logger()
        if mercadopago is None:
            lg.error("SDK mercadopago no disponible (pip install mercadopago)")
            raise RuntimeError("SDK mercadopago no disponible")

        token = access_token or os.getenv("MP_ACCESS_TOKEN")
        if not token:
            lg.error("MP_ACCESS_TOKEN no configurado")
            raise RuntimeError("MP_ACCESS_TOKEN no configurado")

        self._sdk = mercadopago.SDK(token)
        lg.debug("Mercado Pago SDK inicializado")

    def create_preference(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Crea una Checkout Preference y devuelve el body de respuesta.

        El SDK retorna: {"status": <int>, "response": {...}}.
        Si el status != 201, se registra el detalle y se lanza RuntimeError
        con `status`, `error` y `message` que provee la API.
        """
        lg = _get_logger()

        # --- Bloque solicitado (completo) ---
        result = self._sdk.preference().create(payload)
        status = int(result.get("status", 0))
        body = result.get("response", {}) or {}
        if status != 201:
            # Ej. {"error":"invalid_notification_url","message":"notification_url attribute must be a valid url"}
            lg.error("MP preference error", extra={"status": status, "body": body})
            raise RuntimeError(
                f"Error creando preferencia MP (status={status}, error={body.get('error')}, message={body.get('message')})"
            )
        # ------------------------------------

        lg.info(
            "Preference creada correctamente",
            extra={
                "status": status,
                "preference_id": body.get("id"),
                "init_point": body.get("init_point") or body.get("sandbox_init_point"),
            },
        )
        return body

    def get_payment(self, payment_id: str | int) -> Dict[str, Any]:
        """
        Obtiene un Payment por id. Lanza RuntimeError si la API no responde 2xx.
        """
        lg = _get_logger()
        result = self._sdk.payment().get(str(payment_id))
        status = int(result.get("status", 0))
        body = result.get("response", {}) or {}

        if status < 200 or status >= 300:
            lg.error("Error obteniendo pago MP", extra={"status": status, "payment_id": payment_id, "body": body})
            raise RuntimeError(f"Error obteniendo pago MP (status={status})")

        lg.info(
            "Payment obtenido",
            extra={
                "status": status,
                "payment_id": body.get("id"),
                "status_detail": body.get("status"),
                "external_reference": body.get("external_reference"),
            },
        )
        return body
