# app/extensions.py
# -*- coding: utf-8 -*-
from __future__ import annotations
from flask_mail import Mail

mail = Mail()
