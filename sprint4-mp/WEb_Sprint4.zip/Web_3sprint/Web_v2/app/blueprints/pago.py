"""Blueprint de pagos integrando Mercado Pago Checkout Pro."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping
from urllib.parse import urlparse

from flask import (
    Blueprint,
    current_app,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

import app.db as db_mod
from app.data.seed import COMBOS_CATALOG
from app.db import execute
from app.service.emailer import enviar_ticket
from app.service.mpago import MPagoClient
from app.service.pdfs import generar_comprobante_pdf
from app.service.qrs import generar_qr

bp = Blueprint("pago", __name__)


# ---------------- Utilidades de sesión / carrito ---------------- #

def _combos_from_session() -> List[dict]:
    ids = [int(x) for x in session.get("combos", [])]
    idset = set(ids)
    return [c for c in COMBOS_CATALOG if c["id"] in idset]


def _seleccion_from_session() -> dict:
    return session.get("movie_selection", {}) or {}


def _seats_from_session() -> List[str]:
    return session.get("seats", []) or []


def _precio_entrada() -> Decimal:
    raw = str(current_app.config.get("TICKET_PRICE", "100"))
    try:
        return Decimal(raw)
    except Exception:  # noqa: BLE001
        return Decimal("100")


def _calcular_totales_server_side() -> tuple[Decimal, Decimal, Decimal, list[dict], list[str], dict]:
    two = Decimal("0.01")
    precio_ent = _precio_entrada()
    seats = _seats_from_session()
    combos_sel = _combos_from_session()
    seleccion = _seleccion_from_session()

    total_entradas = (precio_ent * Decimal(len(seats))).quantize(two, rounding=ROUND_HALF_UP)
    total_combos = sum(Decimal(str(c.get("precio", 0))) for c in combos_sel)
    total_combos = Decimal(total_combos).quantize(two, rounding=ROUND_HALF_UP)
    total = (total_entradas + total_combos).quantize(two, rounding=ROUND_HALF_UP)
    return total_entradas, total_combos, total, combos_sel, seats, seleccion


def build_items_from_cart(carrito: Mapping[str, Any]) -> List[dict]:
    """Convierte el carrito a ítems compatibles con la API de preferencias."""
    items: List[dict] = []

    entradas = carrito.get("entradas") if isinstance(carrito, Mapping) else None
    if isinstance(entradas, Mapping):
        quantity = int(entradas.get("quantity", 0) or 0)
        unit_price = float(entradas.get("unit_price", 0) or 0)
        title = entradas.get("title") or "Entradas"
        if quantity > 0 and unit_price > 0:
            items.append(
                {
                    "title": str(title),
                    "quantity": quantity,
                    "currency_id": str(entradas.get("currency_id") or "ARS"),
                    "unit_price": round(unit_price, 2),
                }
            )

    combos = carrito.get("combos") if isinstance(carrito, Mapping) else None
    if isinstance(combos, Iterable):
        for combo in combos:
            if not isinstance(combo, Mapping):
                continue
            title = combo.get("title") or combo.get("nombre")
            price = float(combo.get("unit_price", combo.get("precio", 0)) or 0)
            quantity = int(combo.get("quantity", 1) or 0)
            if quantity <= 0 or price <= 0:
                continue
            items.append(
                {
                    "title": str(title or "Combo"),
                    "quantity": quantity,
                    "currency_id": str(combo.get("currency_id") or "ARS"),
                    "unit_price": round(price, 2),
                }
            )

    return items


# ---------------- Config / helpers ---------------- #

def _get_mp_client() -> MPagoClient:
    token = current_app.config.get("MP_ACCESS_TOKEN") or os.getenv("MP_ACCESS_TOKEN")
    return MPagoClient(token)


def _base_url() -> str:
    base = current_app.config.get("BASE_URL")
    if base:
        return str(base).rstrip("/")
    return request.url_root.rstrip("/")


def _is_public_https(url: str) -> bool:
    """True si es https y no es localhost/127.0.0.1 (requerido para webhooks)."""
    try:
        u = urlparse(url or "")
        host = (u.hostname or "").lower()
        return u.scheme == "https" and host not in {"127.0.0.1", "localhost"}
    except Exception:
        return False


# ---------------- Firma Webhook (x-signature) ---------------- #

def _parse_signature_header(header: str) -> dict:
    """x-signature: 'ts=...,v1=...' -> {'ts': '...', 'v1': '...'}"""
    parsed: dict[str, str] = {}
    for part in (header or "").split(","):
        if "=" not in part:
            continue
        k, v = part.strip().split("=", 1)
        parsed[k.strip()] = v.strip()
    return parsed


def _validate_signature(secret: str, header: str, request_id: str, obj_id: str) -> bool:
    """
    Manifest según guía MP:
      'id:{obj_id};request-id:{x-request-id};ts:{ts};'
    v1 debe ser HMAC_SHA256(secret, manifest).
    """
    params = _parse_signature_header(header)
    ts = params.get("ts")
    v1 = params.get("v1")
    if not (secret and request_id and obj_id and ts and v1):
        return False

    manifest = f"id:{obj_id};request-id:{request_id};ts:{ts};".encode("utf-8")
    expected = hmac.new(secret.encode("utf-8"), manifest, hashlib.sha256).hexdigest()
    return hmac.compare_digest(v1, expected)


# ---------------- Flujo de finalización / comprobante ---------------- #

def _load_trx_context(trx: Mapping[str, Any]) -> MutableMapping[str, Any]:
    raw = trx.get("raw_mp") if isinstance(trx, Mapping) else None
    if isinstance(raw, Mapping):
        return dict(raw)
    if isinstance(raw, str) and raw.strip():
        try:
            return dict(json.loads(raw))
        except Exception:  # noqa: BLE001
            return {}
    return {}


def _finalize_transaction(
    trx: Mapping[str, Any],
    context: MutableMapping[str, Any],
    payment: Mapping[str, Any],
) -> None:
    metadata = context.setdefault("metadata", {})
    if metadata.get("ticket_emitted"):
        return

    trx_id = int(trx.get("id"))
    usuario_email = trx.get("usuario_email")
    selection = metadata.get("selection") or {}
    hold_token = metadata.get("hold_token")
    seats = metadata.get("seats") or []
    combos = metadata.get("combos") or []

    confirmed: List[str] = []
    if hold_token and selection.get("id"):
        try:
            confirmed = db_mod.confirm_seats(
                token=hold_token,
                movie_id=selection.get("id"),
                fecha=selection.get("fecha"),
                hora=selection.get("hora"),
                sala=selection.get("sala"),
                usuario_email=usuario_email or None,
                trx_id=trx_id,
            )
        except ValueError as exc:  # noqa: BLE001
            current_app.logger.warning("No se pudieron confirmar asientos: %s", exc)
    else:
        current_app.logger.warning(
            "Faltan datos para confirmar asientos (trx_id=%s, hold_token=%s)",
            trx_id,
            hold_token,
        )

    if confirmed:
        metadata["confirmed_seats"] = confirmed
    else:
        metadata.setdefault("confirmed_seats", seats)

    sucursal = metadata.get("sucursal") or session.get("branch") or current_app.config.get("DEFAULT_BRANCH", "-")
    auth_code = payment.get("id") or payment.get("authorization_code")
    qr_path = generar_qr(
        trx_id=trx_id,
        verify_url=None,
        extra={"email": usuario_email, "auth": str(auth_code or "")},
    )

    total = float(metadata.get("total") or (trx.get("monto_cents", 0) or 0) / 100.0)
    pdf_path = generar_comprobante_pdf(
        trx_id=trx_id,
        cliente=usuario_email or metadata.get("nombre") or "-",
        email=usuario_email or "-",
        pelicula=selection.get("titulo", "-"),
        fecha_funcion=selection.get("fecha", "-"),
        hora_funcion=selection.get("hora", "-"),
        sala=selection.get("sala", "-"),
        asientos=metadata.get("confirmed_seats") or seats,
        combos=[
            {
                "nombre": c.get("nombre") or c.get("title"),
                "cantidad": int(c.get("quantity", 1) or 1),
                "precio": float(c.get("precio", c.get("unit_price", 0)) or 0),
                "descripcion": c.get("descripcion"),
            }
            for c in combos
        ],
        total=total,
        sucursal=sucursal,
        qr_path=qr_path,
    )

    metadata["qr_path"] = qr_path
    metadata["pdf_path"] = pdf_path
    metadata["ticket_emitted"] = True

    if usuario_email:
        try:
            enviar_ticket(
                destino=usuario_email,
                asunto=f"Comprobante TRX #{trx_id}",
                cuerpo=(
                    f"Gracias por su compra.\n\n"
                    f"Sucursal: {sucursal}\n"
                    f"Película: {selection.get('titulo', '-')}\n"
                    f"Fecha/Hora: {selection.get('fecha', '-')} {selection.get('hora', '-')}\n"
                    f"Asientos: {', '.join(metadata.get('confirmed_seats') or [])}\n"
                    f"Monto: ${total:.2f}\n"
                    f"Código de pago: {auth_code}\n"
                ),
                adjunto_path=pdf_path,
            )
            metadata["email_sent"] = True
        except Exception as exc:  # noqa: BLE001
            current_app.logger.warning("No se pudo enviar el comprobante: %s", exc)


# ---------------- Endpoints ---------------- #

@bp.post("/pago/checkout")
def checkout() -> Any:
    payload = request.get_json(silent=True) or {}
    email = (payload.get("email") or session.get("user_autofill", {}).get("email") or "").strip()
    if not email:
        return jsonify({"error": "Email requerido"}), 400

    total_entradas, total_combos, total, combos_sel, seats, seleccion = _calcular_totales_server_side()
    if not seats or not seleccion:
        return jsonify({"error": "Seleccioná función y asientos antes de pagar."}), 400

    hold_token = session.get("hold_token")
    if not hold_token:
        return jsonify({"error": "No hay retenciones vigentes de asientos."}), 400

    monto_cents = int((total * 100).to_integral_value(rounding=ROUND_HALF_UP))
    if monto_cents <= 0:
        return jsonify({"error": "Monto inválido"}), 400

    now_iso = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    trx_id = execute(
        """
        INSERT INTO transacciones (usuario_email, monto_cents, estado, created_at, mp_status)
        VALUES (?, ?, ?, ?, ?)
        """,
        [email, monto_cents, "PENDIENTE", now_iso, "pending"],
        commit=True,
    )

    carrito = {
        "entradas": {
            "title": f"Entradas {seleccion.get('titulo', '')}",
            "quantity": len(seats),
            "currency_id": "ARS",
            "unit_price": float(_precio_entrada()),
        },
        "combos": [
            {
                "title": c.get("nombre"),
                "descripcion": c.get("descripcion"),
                "quantity": 1,
                "currency_id": "ARS",
                "unit_price": float(c.get("precio", 0) or 0),
            }
            for c in combos_sel
        ],
    }
    items = build_items_from_cart(carrito)
    if not items:
        return jsonify({"error": "No hay ítems para pagar."}), 400

    metadata = {
        "selection": seleccion,
        "seats": seats,
        "combos": combos_sel,
        "hold_token": hold_token,
        "total": float(total),
        "total_entradas": float(total_entradas),
        "total_combos": float(total_combos),
        "sucursal": session.get("branch") or current_app.config.get("DEFAULT_BRANCH", "-"),
        "email": email,
    }

    base = _base_url()
    is_public = _is_public_https(base)

    preference_payload: Dict[str, Any] = {
        "items": items,
        "external_reference": str(trx_id),
        "payer": {"email": email},
        "metadata": metadata,
        "back_urls": {
            "success": f"{base}{url_for('pago.success')}",
            "failure": f"{base}{url_for('pago.failure')}",
            "pending": f"{base}{url_for('pago.pending')}",
        },
        "auto_return": "approved",
        # "binary_mode": True,  # opcional: sólo approved/rejected
    }

    # Sólo incluir notification_url si es HTTPS público (ngrok/dominio)
    if is_public:
        preference_payload["notification_url"] = f"{base}{url_for('pago.webhook')}"
    else:
        current_app.logger.info("Omitiendo notification_url en dev (BASE_URL no pública): %s", base)

    mp_client = _get_mp_client()
    preference = mp_client.create_preference(preference_payload)

    preference_id = preference.get("id") or preference.get("preference_id")
    init_point = preference.get("init_point") or preference.get("sandbox_init_point")

    context = {
        "metadata": metadata,
        "preference": {"id": preference_id, "init_point": init_point},
    }

    execute(
        """
        UPDATE transacciones
           SET mp_preference_id=?, mp_status=?, raw_mp=?
         WHERE id=?
        """,
        [preference_id, "pending", json.dumps(context, ensure_ascii=False), trx_id],
        commit=True,
    )

    session["last_trx_id"] = trx_id
    session.modified = True

    current_app.logger.info(
        "MP checkout creado: trx_id=%s preference=%s monto=%s",
        trx_id, preference_id, total,
    )

    response_payload = {
        "redirect": init_point,
        "preference_id": preference_id,
        "transaction_id": trx_id,
        "public_key": current_app.config.get("MP_PUBLIC_KEY"),
    }

    if request.content_type and "application/json" in request.content_type:
        return jsonify(response_payload)
    if init_point:
        return redirect(init_point)
    return jsonify(response_payload)


@bp.post("/pago/webhook")
def webhook() -> Any:
    secret = current_app.config.get("WEBHOOK_SECRET")
    if not secret:
        current_app.logger.error("WEBHOOK_SECRET no configurado")
        return jsonify({"error": "Misconfigured"}), 500

    payload = request.get_json(silent=True) or {}
    header = request.headers.get("x-signature", "")
    request_id = request.headers.get("x-request-id", "")

    # Obtener primero el id (payment_id) desde el body para el manifest
    data = payload.get("data") if isinstance(payload, Mapping) else None
    payment_id = data.get("id") if isinstance(data, Mapping) else payload.get("id")
    if not payment_id:
        return jsonify({"error": "Missing payment id"}), 400

    # Validar firma con id + request-id + ts (x-signature)
    if not _validate_signature(secret, header, request_id, str(payment_id)):
        current_app.logger.warning("Firma inválida en webhook")
        return jsonify({"error": "Invalid signature"}), 400

    mp_client = _get_mp_client()
    payment = mp_client.get_payment(payment_id)

    external_reference = payment.get("external_reference")
    if external_reference is None:
        return jsonify({"error": "Missing external reference"}), 400

    try:
        trx_id = int(external_reference)
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid external reference"}), 400

    trx = db_mod.get_transaccion(trx_id)
    if not trx:
        return jsonify({"error": "Transaction not found"}), 404

    status = (payment.get("status") or "").lower()
    context = _load_trx_context(trx)
    context["payment"] = payment

    updates: Dict[str, Any] = {
        "mp_payment_id": str(payment.get("id") or payment_id),
        "mp_status": payment.get("status"),
    }

    if status == "approved" and (trx.get("estado") or "").upper() != "APROBADO":
        _finalize_transaction(trx, context, payment)
        updates["estado"] = "APROBADO"
        auth_code = payment.get("id") or payment.get("authorization_code")
        if auth_code:
            updates["auth_code"] = str(auth_code)
        brand = payment.get("payment_method_id")
        if brand:
            updates["brand"] = str(brand).upper()
        card = payment.get("card") or {}
        last4 = card.get("last_four_digits")
        if last4:
            updates["last4"] = str(last4)
    elif status in {"rejected", "cancelled"}:
        updates["estado"] = "RECHAZADA"
    elif status in {"pending", "in_process"}:
        updates["estado"] = "PENDIENTE"

    updates["raw_mp"] = json.dumps(context, ensure_ascii=False)
    db_mod.update_transaccion(trx_id, **updates)

    current_app.logger.info(
        "Webhook MP: payment_id=%s status=%s external_ref=%s monto=%s",
        payment.get("id"),
        payment.get("status"),
        external_reference,
        payment.get("transaction_amount"),
    )
    return jsonify({"status": "ok"})


@bp.get("/pago/success")
def success() -> Any:
    ref = request.args.get("external_reference") or request.args.get("trx") or session.get("last_trx_id")
    if not ref:
        flash("No encontramos la transacción asociada al pago.", "warning")
        return redirect(url_for("venta.confirmacion"))
    try:
        trx_id = int(ref)
    except (TypeError, ValueError):
        flash("Referencia de transacción inválida.", "danger")
        return redirect(url_for("venta.confirmacion"))

    trx = db_mod.get_transaccion(trx_id)
    if not trx:
        flash("Transacción no encontrada.", "danger")
        return redirect(url_for("venta.confirmacion"))

    if (trx.get("estado") or "").upper() != "APROBADO":
        flash("Estamos procesando tu pago. Vas a recibir un email al confirmarse.", "info")
        return redirect(url_for("venta.confirmacion"))

    return _render_success(trx)


@bp.get("/pago/pending")
def pending() -> Any:
    flash("Tu pago está pendiente de acreditación. Te avisaremos por email.", "info")
    return redirect(url_for("venta.confirmacion"))


@bp.get("/pago/failure")
def failure() -> Any:
    flash("El pago fue cancelado o rechazado. Podés intentar nuevamente.", "danger")
    return redirect(url_for("venta.confirmacion"))
