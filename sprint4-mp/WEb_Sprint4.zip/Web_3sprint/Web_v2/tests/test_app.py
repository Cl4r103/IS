import hashlib
import hmac
import json
import os
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from unittest import TestCase
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import create_app
import app.db as db_mod


class BaseTestCase(TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        os.environ["DB_PATH"] = os.path.join(self.tempdir.name, "test.db")
        os.environ["MP_ACCESS_TOKEN"] = "test-token"
        os.environ["MP_PUBLIC_KEY"] = "pub-test"
        os.environ["WEBHOOK_SECRET"] = "super-secret"
        os.environ["BASE_URL"] = "https://example.com"
        self.app = create_app()
        self.app.config["TESTING"] = True
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()

    def tearDown(self):
        self.app_context.pop()
        self.tempdir.cleanup()
        for key in ["DB_PATH", "MP_ACCESS_TOKEN", "MP_PUBLIC_KEY", "WEBHOOK_SECRET", "BASE_URL"]:
            os.environ.pop(key, None)


class TestApp(BaseTestCase):
    def test_home_page(self):
        response = self.client.get("/", follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn("Bienvenido a", response.data.decode("utf-8"))

    @patch("app.blueprints.pago._get_mp_client")
    def test_checkout_creates_preference(self, mock_client_factory):
        mock_client = MagicMock()
        mock_client.create_preference.return_value = {
            "id": "pref-123",
            "init_point": "https://mp.test/init",
        }
        mock_client_factory.return_value = mock_client

        with self.client.session_transaction() as sess:
            sess["movie_selection"] = {
                "id": "m1",
                "titulo": "Nebula 9",
                "sala": "Sala 1",
                "fecha": "2025-09-29",
                "hora": "18:30",
            }
            sess["seats"] = ["A1", "A2"]
            sess["combos"] = [1]
            sess["hold_token"] = "hold-xyz"
            sess["user_autofill"] = {"email": "buyer@example.com"}

        response = self.client.post("/pago/checkout", json={"email": "buyer@example.com"})
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data["preference_id"], "pref-123")
        self.assertTrue(data["redirect"].startswith("https://mp.test"))

        trx = db_mod.get_transaccion(data["transaction_id"])
        self.assertEqual(trx["estado"], "PENDIENTE")
        self.assertEqual(trx["mp_preference_id"], "pref-123")
        self.assertEqual(trx["usuario_email"], "buyer@example.com")

        mock_client.create_preference.assert_called_once()
        payload = mock_client.create_preference.call_args.args[0]
        self.assertEqual(payload["external_reference"], str(data["transaction_id"]))

    @patch("app.blueprints.pago.enviar_ticket")
    @patch("app.blueprints.pago.generar_comprobante_pdf")
    @patch("app.blueprints.pago.generar_qr")
    @patch("app.blueprints.pago.db_mod.confirm_seats")
    @patch("app.blueprints.pago._get_mp_client")
    def test_webhook_approved_updates_transaction(
        self,
        mock_client_factory,
        mock_confirm,
        mock_qr,
        mock_pdf,
        mock_enviar,
    ):
        metadata = {
            "selection": {
                "id": "m1",
                "titulo": "Nebula 9",
                "sala": "Sala 1",
                "fecha": "2025-09-29",
                "hora": "18:30",
            },
            "seats": ["A1", "A2"],
            "combos": [],
            "hold_token": "hold-xyz",
            "total": 10000.0,
            "sucursal": "Cine Test",
        }
        context = {"metadata": metadata}
        now_iso = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        trx_id = db_mod.insert_transaccion(
            usuario_email="buyer@example.com",
            monto_cents=10000,
            estado="PENDIENTE",
            created_at=now_iso,
            mp_status="pending",
            raw_mp=json.dumps(context),
        )

        mock_confirm.return_value = ["A1", "A2"]
        mock_qr.return_value = "qr.png"
        mock_pdf.return_value = "ticket.pdf"

        webhook_client = MagicMock()
        webhook_client.get_payment.return_value = {
            "id": "pay-001",
            "external_reference": str(trx_id),
            "status": "approved",
            "payment_method_id": "visa",
            "transaction_amount": 100.0,
            "card": {"last_four_digits": "4242"},
        }
        mock_client_factory.return_value = webhook_client

        request_id = "req-123"
        ts = "1700000000"
        signature_raw = f"id:pay-001;ts:{ts};request-id:{request_id}"
        signature = hmac.new(
            os.environ["WEBHOOK_SECRET"].encode("utf-8"),
            signature_raw.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        headers = {
            "x-request-id": request_id,
            "x-signature": f"id=pay-001;ts={ts};signature={signature}",
            "Content-Type": "application/json",
        }
        payload = {"data": {"id": "pay-001"}}

        response = self.client.post("/pago/webhook", data=json.dumps(payload), headers=headers)
        self.assertEqual(response.status_code, 200)

        updated = db_mod.get_transaccion(trx_id)
        self.assertEqual(updated["estado"], "APROBADO")
        self.assertEqual(updated["mp_payment_id"], "pay-001")
        self.assertEqual(updated["brand"], "VISA")
        self.assertEqual(updated["last4"], "4242")

        raw = json.loads(updated["raw_mp"])
        self.assertTrue(raw["metadata"]["ticket_emitted"])
        self.assertEqual(raw["metadata"]["confirmed_seats"], ["A1", "A2"])

        mock_confirm.assert_called_once()
        args, kwargs = mock_confirm.call_args
        self.assertEqual(kwargs["token"], "hold-xyz")
        mock_qr.assert_called_once()
        mock_pdf.assert_called_once()
        mock_enviar.assert_called_once()

    @patch("app.blueprints.pago._get_mp_client")
    def test_webhook_invalid_signature_rejected(self, mock_client_factory):
        metadata = {
            "selection": {
                "id": "m1",
                "titulo": "Nebula 9",
                "sala": "Sala 1",
                "fecha": "2025-09-29",
                "hora": "18:30",
            },
            "seats": ["A1"],
            "hold_token": "hold-xyz",
        }
        context = {"metadata": metadata}
        trx_id = db_mod.insert_transaccion(
            usuario_email="buyer@example.com",
            monto_cents=5000,
            estado="PENDIENTE",
            created_at=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            mp_status="pending",
            raw_mp=json.dumps(context),
        )

        headers = {
            "x-request-id": "req-abc",
            "x-signature": "id=pay-001;ts=1;signature=invalid",
            "Content-Type": "application/json",
        }

        response = self.client.post(
            "/pago/webhook",
            data=json.dumps({"data": {"id": "pay-001"}}),
            headers=headers,
        )

        self.assertEqual(response.status_code, 400)
        updated = db_mod.get_transaccion(trx_id)
        self.assertEqual(updated["estado"], "PENDIENTE")
        mock_client_factory.assert_not_called()